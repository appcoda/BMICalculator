//
//  PreferencesViewController.swift
//  BMI Calculator
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2019 Appcoda. All rights reserved.
//

import Cocoa

class PreferencesViewController: NSViewController {

    // MARK: - IBOutlet Properties
    
    @IBOutlet weak var metricRadio: NSButton!
    
    @IBOutlet weak var imperialRadio: NSButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
